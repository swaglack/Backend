const {Workspaces, UserWorkspaces, Users} = require('../models')

class WorkspaceRepository {
  postWorkspace = async (workspaceName,workspaceMaster) => {
    try {
      console.log(workspaceMaster,workspaceName)
      const postWorkspace = await Workspaces.create({
        workspaceName : workspaceName,
        userId : workspaceMaster,
      })
      .then(
        (result) => {
          const workspaceId = result.dataValues.workspaceId
          UserWorkspaces.create({
            userId : workspaceMaster,
            workspaceId : workspaceId
          })
      })
      .catch(err => console.log(err))
      return postWorkspace;
    } catch (err) {
      return err;
    }
  };

  getAllWorkspace = async (userId) => {
    console.log(userId)
    try {
      const allWorkspace = await Users.findByPk(userId, {
          include:[Workspaces]
      });
      return allWorkspace
    } catch(err) {
      return err;
    }

  }

  getOneWorkspace = async (workspaceId) => {
    try {
      const getOneWorkspace = await Workspaces.findByPk(workspaceId.workspaceid ,{
        include:[Users]
      });
      return getOneWorkspace;
    } catch(err) {
      return err;
    }
    
  }

  putWorkspace = async (workspaceId) => {
    try {
      const putWorkspace = await Workspaces.updateOne({
        workspaceId : workspaceId
      }, {
        '$push' : {workspaceMember : workspaceMember}
      })
      return putWorkspace;
    } catch(err) {
      return err;
    }

  }

  deleteWorkspace = async (workspaceId,workspaceMater) => {
    try {
      const deleteWorkspace = await Workspace.deleteOne({
        workspaceId : workspaceId,
        workspaceMater : workspaceMater
      })
      console.log(typeof deleteWorkspace)
      return deleteWorkspace;
    } catch(err) {
      return err;
    }
  }
}

module.exports = WorkspaceRepository;